-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 02, 2020 at 04:07 AM
-- Server version: 5.7.26
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `harshana`
--

-- --------------------------------------------------------

--
-- Table structure for table `el_form_data`
--

DROP TABLE IF EXISTS `el_form_data`;
CREATE TABLE IF NOT EXISTS `el_form_data` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone_number` varchar(10) DEFAULT NULL,
  `question_1` int(1) DEFAULT NULL,
  `question_2` int(1) DEFAULT NULL,
  `question_3` int(1) DEFAULT NULL,
  `question_4` int(1) DEFAULT NULL,
  `question_5` int(1) DEFAULT NULL,
  `question_6` int(1) DEFAULT NULL,
  `question_7` int(1) DEFAULT NULL,
  `question_8` int(1) DEFAULT NULL,
  `question_9` int(1) DEFAULT NULL,
  `question_10` int(1) DEFAULT NULL,
  `question_11` int(1) DEFAULT NULL,
  `question_12` int(1) DEFAULT NULL,
  `question_13` int(1) DEFAULT NULL,
  `question_14` int(1) DEFAULT NULL,
  `question_15` int(1) DEFAULT NULL,
  `question_16` int(1) DEFAULT NULL,
  `question_17` int(1) DEFAULT NULL,
  `question_18` int(1) DEFAULT NULL,
  `question_19` int(1) DEFAULT NULL,
  `question_20` int(1) DEFAULT NULL,
  `question_21` int(1) DEFAULT NULL,
  `question_22` int(1) DEFAULT NULL,
  `question_23` int(1) DEFAULT NULL,
  `question_24` int(1) DEFAULT NULL,
  `question_25` int(1) DEFAULT NULL,
  `question_26` int(1) DEFAULT NULL,
  `question_27` int(1) DEFAULT NULL,
  `question_28` int(1) DEFAULT NULL,
  `question_29` int(1) DEFAULT NULL,
  `question_30` int(1) DEFAULT NULL,
  `question_31` int(1) DEFAULT NULL,
  `question_32` int(1) DEFAULT NULL,
  `question_33` int(1) DEFAULT NULL,
  `question_34` int(1) DEFAULT NULL,
  `question_35` int(1) DEFAULT NULL,
  `question_36` int(1) DEFAULT NULL,
  `question_37` int(1) DEFAULT NULL,
  `question_38` int(1) DEFAULT NULL,
  `question_39` int(1) DEFAULT NULL,
  `question_40` int(1) DEFAULT NULL,
  `question_41` int(1) DEFAULT NULL,
  `question_42` int(1) DEFAULT NULL,
  `question_43` int(1) DEFAULT NULL,
  `question_44` int(1) DEFAULT NULL,
  `question_45` int(1) DEFAULT NULL,
  `question_46` int(1) DEFAULT NULL,
  `question_47` int(1) DEFAULT NULL,
  `question_48` int(1) DEFAULT NULL,
  `question_49` int(1) DEFAULT NULL,
  `question_50` int(1) DEFAULT NULL,
  `question_51` int(1) DEFAULT NULL,
  `question_52` int(1) DEFAULT NULL,
  `question_53` int(1) DEFAULT NULL,
  `question_54` int(1) DEFAULT NULL,
  `question_55` int(1) DEFAULT NULL,
  `question_56` int(1) DEFAULT NULL,
  `question_57` int(1) DEFAULT NULL,
  `question_58` int(1) DEFAULT NULL,
  `question_59` int(1) DEFAULT NULL,
  `question_60` int(1) DEFAULT NULL,
  `ap_question_1` int(1) DEFAULT NULL,
  `ap_question_2` int(1) DEFAULT NULL,
  `ap_question_3` int(1) DEFAULT NULL,
  `ap_question_4` int(1) DEFAULT NULL,
  `ap_question_5` int(1) DEFAULT NULL,
  `ap_question_6` int(1) DEFAULT NULL,
  `ap_question_7` int(1) DEFAULT NULL,
  `ap_question_8` int(1) DEFAULT NULL,
  `verified` tinyint(1) DEFAULT NULL,
  `uploaded_cv` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `el_form_data`
--

INSERT INTO `el_form_data` (`id`, `full_name`, `email`, `phone_number`, `question_1`, `question_2`, `question_3`, `question_4`, `question_5`, `question_6`, `question_7`, `question_8`, `question_9`, `question_10`, `question_11`, `question_12`, `question_13`, `question_14`, `question_15`, `question_16`, `question_17`, `question_18`, `question_19`, `question_20`, `question_21`, `question_22`, `question_23`, `question_24`, `question_25`, `question_26`, `question_27`, `question_28`, `question_29`, `question_30`, `question_31`, `question_32`, `question_33`, `question_34`, `question_35`, `question_36`, `question_37`, `question_38`, `question_39`, `question_40`, `question_41`, `question_42`, `question_43`, `question_44`, `question_45`, `question_46`, `question_47`, `question_48`, `question_49`, `question_50`, `question_51`, `question_52`, `question_53`, `question_54`, `question_55`, `question_56`, `question_57`, `question_58`, `question_59`, `question_60`, `ap_question_1`, `ap_question_2`, `ap_question_3`, `ap_question_4`, `ap_question_5`, `ap_question_6`, `ap_question_7`, `ap_question_8`, `verified`, `uploaded_cv`) VALUES
(8, 'vishwa', 'dulan@ieee.org', '0716250646', -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, 1, 0, -3, -3, -3, -3, -3, -3, -3, -3, -3, -2, -1, -1, 0, 2, 3, 3, 2, 1, -2, -2, 2, 2, -1, -3, -3, 0, -1, 3, 2, 1, -1, -2, 2, -2, 2, 3, 0, 'uploads/jobs.route.js');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `created_at`) VALUES
(1, 'admin@harshana.com', 'e10adc3949ba59abbe56e057f20f883e', '2020-10-02 09:36:21');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
